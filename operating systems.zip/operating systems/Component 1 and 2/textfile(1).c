#include <stdio.h>

int main() {
    FILE *filePointer;
    char fileName[100]; // Increased size to handle longer file names
    char text[1000];    // Increased size to handle longer texts

    // Get file name from the user
    printf("Enter the file name: ");
    scanf("%s", fileName);

    // Get text from the user
    printf("Enter the text you want to store in the file:\n");
    getchar(); // Consume the newline character left in the buffer
    fgets(text, sizeof(text), stdin);

    // Create a text file and write the text into it
    filePointer = fopen(fileName, "w");

    if (filePointer == NULL) {
        printf("Error opening the file.\n");
        return 1;
    }

    fprintf(filePointer, "%s", text);
    fclose(filePointer);

    // Open the file again in read mode to display its content
    filePointer = fopen(fileName, "r");

    if (filePointer == NULL) {
        printf("Error opening the file.\n");
        return 1;
    }

    printf("Content of the file:\n");

    int ch;
    while ((ch = fgetc(filePointer)) != EOF) {
        printf("%c", ch);
    }

    fclose(filePointer);

    return 0;
}
