#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main() {
    int guess, target, attempts, score = 0;
    char playAgain, showScoreboard;

    // Seed the random number generator with the current time
    srand(time(NULL));

    do {
        // Generate a random number between 1 and 5000
        target = rand() % 5000 + 1;
        attempts = 0;

        printf("\nWelcome to the Number Guessing Game!\n");
        printf("Guess a number between 1 and 5000.\n");

        do {
            printf("Enter your guess: ");
            scanf("%d", &guess);

            if (guess < 1 || guess > 5000) {
                printf("Your guess is out of bounds. Quitting the game. Thanks for playing!\n");
                return 0;
            }

            attempts++;

            if (guess == target) {
                printf("Congratulations! You guessed the correct number in %d attempts.\n", attempts);
                score += attempts;
            } else if (guess < target) {
                printf("Try a higher number.\n");
            } else {
                printf("Try a lower number.\n");
            }

        } while (guess != target);

        // Ask if the user wants to display the scoreboard or play again
        printf("Do you want to display the scoreboard? (y/n): ");
        scanf(" %c", &showScoreboard);

        if (showScoreboard == 'y' || showScoreboard == 'Y') {
            printf("Scoreboard: %d\n", score);
        }

        // Ask if the user wants to play again
        printf("Do you want to play again? (y/n): ");
        scanf(" %c", &playAgain);

    } while (playAgain == 'y' || playAgain == 'Y');

    printf("\nThank you for playing! Your final score is: %d\n", score);

    return 0;
}
