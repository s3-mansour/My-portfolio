#include <stdio.h>

int main() {
    int rows, i, j;

    // Get the number of rows from the user
    printf("Enter the number of rows (odd number): ");
    scanf("%d", &rows);

    if (rows % 2 == 0) {
        printf("Please enter an odd number of rows for a symmetric diamond.\n");
        return 1;
    }

    // Upper part of the pattern
    for (i = 0; i < rows / 2 + 1; i++) {
        // Print spaces before the star
        for (j = i; j < rows / 2; j++) {
            printf(" ");
        }

        // Print stars
        for (j = 0; j < (2 * i + 1); j++) {
            printf("*");
        }

        printf("\n");
    }

    // Lower part of the pattern
    for (i = rows / 2 - 1; i >= 0; i--) {
        // Print spaces before the star
        for (j = rows / 2; j > i; j--) {
            printf(" ");
        }

        // Print stars
        for (j = 0; j < (2 * i + 1); j++) {
            printf("*");
        }

        printf("\n");
    }

    return 0;
}
