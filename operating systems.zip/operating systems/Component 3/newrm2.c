#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>
#include <dirent.h>

#define TRASH_DIR ".custom_trash"
#define METADATA_FILE ".metadata"
#define MAX_PATH 4096

void create_trash_dir() {
    mkdir(TRASH_DIR, 0777);
}

void move_to_trash(const char *file) {
    char trash_path[MAX_PATH];
    char metadata_path[MAX_PATH];
    snprintf(trash_path, sizeof(trash_path), "%s/%s", TRASH_DIR, basename((char *)file));
    snprintf(metadata_path, sizeof(metadata_path), "%s/%s", TRASH_DIR, METADATA_FILE);

    FILE *metadata = fopen(metadata_path, "w");
    if (metadata != NULL) {
        fprintf(metadata, "%s\n", file);
        fclose(metadata);
    }

    rename(file, trash_path);
}

void undo_remove() {
    char metadata_path[MAX_PATH];
    snprintf(metadata_path, sizeof(metadata_path), "%s/%s", TRASH_DIR, METADATA_FILE);

    FILE *metadata = fopen(metadata_path, "r");
    if (metadata != NULL) {
        char original_path[MAX_PATH];
        if (fgets(original_path, sizeof(original_path), metadata) != NULL) {
            original_path[strcspn(original_path, "\n")] = 0; // Remove newline
            char *file_name = basename(original_path);
            char *original_dir = dirname(original_path);

            char restored_path[MAX_PATH];
            snprintf(restored_path, sizeof(restored_path), "%s/%s", TRASH_DIR, file_name);
            rename(restored_path, original_path);

            printf("Undo: File '%s' restored to '%s'.\n", file_name, original_dir);
        }
        fclose(metadata);
        remove(metadata_path);
    } else {
        printf("Error: Metadata not found. Cannot undo.\n");
    }
}

int main(int argc, char *argv[]) {
    create_trash_dir();

    for (int i = 1; i < argc; i++) {
        if (access(argv[i], F_OK) != -1) {
            char choice;
            printf("Are you sure you want to remove '%s'? (y/n): ", argv[i]);
            scanf(" %c", &choice);
            if (choice == 'y' || choice == 'Y') {
                move_to_trash(argv[i]);
                printf("File '%s' moved to trash.\n", argv[i]);
            } else {
                printf("File '%s' not removed.\n", argv[i]);
            }
        } else {
            printf("Error: File '%s' not found.\n", argv[i]);
        }
    }

    char undo_choice;
    printf("Do you want to undo the last removal? (y/n): ");
    scanf(" %c", &undo_choice);
    if (undo_choice == 'y' || undo_choice == 'Y') {
        undo_remove();
    } else {
        printf("No undo performed.\n");
    }

    return 0;
}
