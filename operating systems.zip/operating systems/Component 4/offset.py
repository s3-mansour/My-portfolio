from pwn import *
eip_value = 0x6a686a6b
eip_bytes = p32(eip_value)
offset = cyclic_find(eip_bytes)
print(offset)
