from flask import *
from .base import *
from .branch_db import Cursor
from .menu import *

u_menu = Blueprint('u_menu', __name__)


@u_menu.route('/select_menu_branch/', methods = ["POST","GET"])
@role_required("U")
def select_menu_branch():
    with Cursor() as c:
        c.execute("SELECT * from branch")
        branches = c.fetchall()

    return render_template("select_menu_branch.html", branches = branches)


@u_menu.route('/<branch>/u_menu/', methods = ["POST","GET"])
@role_required("U")
def view_u_menu(branch):
    categories = [category.to_dict() for category in MenuCategory.view_categories(branch)]
    items_by_category = {
        cat['cat_id']: [item.to_dict() for item in MenuItem.view_items_by_category(cat['cat_id'], branch)]
        for cat in categories
    }
    return render_template('menu.html', categories = categories, items_by_category = items_by_category)