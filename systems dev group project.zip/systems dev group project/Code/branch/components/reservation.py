from flask import *
from .base import *
from .branch_db import Cursor
from datetime import datetime

res = Blueprint('reservation', __name__)


class Reservation:
    def __init__(self, table_id, amount, name, datetime, id = None, branch_id = None):
        self.id = id
        self.table_id = table_id
        self.amount = amount
        self.name = name
        self.datetime = datetime
        self.branch_id = branch_id

    def view_all_reservations(branch):
        with Cursor() as c:
            c.execute("SELECT * FROM reservation WHERE branch_id = ? ORDER BY datetime ASC", (branch,))
            reservations = c.fetchall()
            return [Reservation(id = row["id"], table_id = row["table"], amount = row["amount"], name = row["name"], datetime = str(row["datetime"])) for row in reservations]
        
    def view_reservation(id, branch):
        with Cursor() as c:
            c.execute("Select * FROM reservation WHERE id = ? AND branch_id = ?", (id, branch,))
            reservation = c.fetchall()
            return [Reservation(id = row["id"], table_id = row["table"], amount = row["amount"], name = row["name"], datetime = str(row["datetime"])) for row in reservation]

    def view_reservation_user(name):
        """
        with Cursor() as c:
            c.execute("Select * FROM reservation WHERE name = ?", (name,))
            reservation = c.fetchall()
            return [Reservation(id = row["id"], table_id = row["table"], amount = row["amount"], name = row["name"], datetime = str(row["datetime"]), branch_id = row["branch_id"]) for row in reservation]
        """
        with Cursor() as c:
            c.execute("SELECT r.id, r.`table` as table_id, r.amount, r.name, r.datetime, r.branch_id, b.name as branch_name FROM reservation r JOIN branch b ON r.branch_id = b.id WHERE r.name = ?", (name,))
            reservations = c.fetchall()
            
            return [
                {
                    'id': row["id"], 
                    'table_id': row["table_id"], 
                    'amount': row["amount"], 
                    'name': row["name"], 
                    'datetime': str(row["datetime"]), 
                    'branch_id': row["branch_id"],
                    'branch_name': row["branch_name"]
                } 
                for row in reservations
            ]

    def create_reservation(reservation, branch):
        with Cursor() as c:
            c.execute("INSERT INTO reservation (`table`, amount, name, datetime, branch_id) VALUES (?, ?, ?, ?, ?)", (reservation.table_id, reservation.amount, reservation.name, reservation.datetime, branch,))

    def update_reservation(id, table_id, amount, name, datetime, branch):
        with Cursor() as c:
            c.execute("UPDATE reservation SET 'table' = ?, amount = ?, name = ?, datetime = ? WHERE id = ? AND branch_id = ?", (table_id, amount, name, datetime, id, branch,))

    def cancel_reservation(id, branch):
        with Cursor() as c:
            c.execute("DELETE FROM reservation WHERE id = ? AND branch_id = ?", (id, branch,))


class Table:
    def __init__(self, id, capacity):
        self.id = id
        self.capacity = capacity

    def check_capacity(amount, branch):
        with Cursor() as c:
            c.execute("SELECT id, capacity FROM `table` WHERE capacity >= ? AND branch_id = ?", (int(amount), branch,))
            tables = c.fetchall()

            if tables is None:
                error = "No available tables for that date"
            else:
                available_tables = []
                for table_id, table_capacity in tables:
                    available_tables.append((table_id, table_capacity))
                return available_tables
            
    def add_duration(original_datetime, hours):
        return datetime(original_datetime.year, original_datetime.month, original_datetime.day, original_datetime.hour + hours, original_datetime.minute)

    def check_availability(amount, reservation_datetime, branch):
        reserve_start = datetime.strptime(reservation_datetime, "%Y-%m-%dT%H:%M")
        reserve_end = Table.add_duration(reserve_start, 2)

        suitable_tables = Table.check_capacity(amount, branch)
        available_tables = []

        with Cursor() as c:
            for table_id, table_capacity in suitable_tables:
                c.execute("SELECT * FROM reservation WHERE `table` = ? AND branch_id = ? AND ((datetime BETWEEN ? AND ?) OR (datetime(reservation.datetime, '+2 hours') BETWEEN ? AND ?))", (table_id, branch, reserve_start, reserve_end, reserve_start, reserve_end))
                if not c.fetchone():
                    available_tables.append((table_id, table_capacity))

        if not available_tables:
            not_available = "No available tables for the selected date and time"
            return not_available
        else:
            return available_tables
        

@res.route('/<branch>/m_reserve/', methods = ["POST","GET"])
@role_required("A", "E")
def m_reserve(branch):
    reservations = Reservation.view_all_reservations(branch)
    return render_template("m_reserve.html", reservations = reservations, branch = branch)


@res.route('/<branch>/create_reservation/', methods = ["POST","GET"])
@role_required("A", "E")
def create_reservation(branch):
    if request.method == 'POST':
        amount = request.form.get('amount')
        name = request.form.get('name')
        datetime = request.form.get('datetime')

        available_tables = Table.check_availability(amount, datetime, branch)

        if isinstance(available_tables, str):
            flash(available_tables, 'error')
            return redirect(url_for('reservation.m_reserve', branch = branch))
        else:
            return render_template("create_reserve.html", tables = available_tables, amount = amount, name = name, datetime = datetime, branch = branch)


@res.route('/<branch>/confirm_reservation/', methods = ["POST","GET"])
@role_required("A", "E")
def confirm_reservation(branch):
    if request.method == 'POST':
        table_id = request.form.get('table_id')
        amount = request.form.get('amount')
        name = request.form.get('name')
        datetime = request.form.get('datetime')

        reservation = Reservation(table_id, amount, name, datetime)

        Reservation.create_reservation(reservation, branch)

        return redirect(url_for('reservation.m_reserve', branch = branch))


@res.route('/<branch>/update_reservation/<string:res_id>/', methods = ["POST","GET"])
@role_required("A", "E")
def update_reservation(res_id, branch):
    if request.method == 'POST':
        id = res_id
        table_id = request.form.get('table_id')
        amount = request.form.get('amount')
        name = request.form.get('name')
        datetime = request.form.get('datetime')

        Reservation.update_reservation(id, table_id, amount, name, datetime, branch)
        return redirect(url_for('reservation.m_reserve', branch = branch))
    
    reservation = Reservation.view_reservation(res_id, branch)
    return render_template('update_reserve.html', reservation = reservation, branch = branch)


@res.route('/<branch>/cancel_reservation/<string:res_id>/', methods = ["POST","GET"])
@role_required("A", "E")
def cancel_reservation(res_id, branch):
    if request.method == 'POST':
        Reservation.cancel_reservation(res_id, branch)

        return redirect(url_for('reservation.m_reserve', branch = branch))