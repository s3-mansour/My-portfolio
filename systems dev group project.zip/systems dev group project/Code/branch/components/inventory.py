from flask import *
from .base import *
from .branch_db import Cursor

inv = Blueprint('inventory', __name__)


class InventoryItem:
    def __init__(self, name, amount, restock_at):
        self.name = name
        self.amount = amount
        self.restock_at = restock_at

    def inventory_update(self):
        return {
            "name" : self.name,
            "amount" : self.amount,
            "restock_at" : self.restock_at
        }

    # Shows entire inventory
    def view_stock(branch):
        with Cursor() as c:
            c.execute("SELECT * FROM inventory_item WHERE branch_id = ?", (branch,))
            items = c.fetchall()
            return [InventoryItem(name = row["name"], amount = row["amount"], restock_at = row["restock_at"]) for row in items]

    # Shows details of specific item (identified by name)
    def view_stock_item(name):
        with Cursor() as c:
            c.execute("SELECT * FROM inventory_item WHERE name = ? AND branch_id = ?", (name, session["branch"],))
            item = c.fetchone()
            return item

    # Creates inventory item with specified name, amount and restock level
    def create_stock_item(item, branch):
        with Cursor() as c:
            c.execute("INSERT INTO inventory_item (name, amount, restock_at, branch_id) VALUES (?, ?, ?, ?)", (item.name, item.amount, item.restock_at, branch,))

    # Updates inventory item of specific name with new name, amount and restock level
    def update_stock(name, new_name, amount, restock_at, branch):
        with Cursor() as c:
            c.execute("UPDATE inventory_item SET name = ?, amount = ?, restock_at = ? WHERE name = ? AND branch_id = ?", (new_name, amount, restock_at, name, branch,))

    # Deletes inventory item of specific name
    def delete_stock_item(name, branch):
        with Cursor() as c:
            c.execute("DELETE FROM inventory_item WHERE name = ? AND branch_id = ?", (name, branch,))

class RawMaterial:
    def __init__(self, name, amount, restock_at, order_more):
        self.name = name
        self.amount = amount
        self.restock_at = restock_at
        self.order_more = order_more

    def materials_update(self):
        return {
            "name" : self.name,
            "amount" : self.amount,
            "restock_at" : self.restock_at,
            "order_more" : self.order_more
        }
    
    def view_materials(branch):
        with Cursor() as c:
            c.execute("SELECT * FROM raw_material WHERE branch_id = ?", (branch,))
            materials = c.fetchall()
            return [RawMaterial(name = row["name"], amount = row["amount"], restock_at = row["restock_at"], order_more = row["order_more"]) for row in materials]
        
    def view_material(name, branch):
        with Cursor() as c:
            c.execute("SELECT * FROM raw_material WHERE name = ? AND branch_id = ?", (name, branch,))
            material = c.fetchone()
            return material
        
    def create_material(material, branch):
        with Cursor() as c:
            c.execute("INSERT INTO raw_material (name, amount, restock_at, order_more, branch_id) VALUES (?, ?, ?, ?, ?)", (material.name, material.amount, material.restock_at, material.order_more, branch,))

    def update_material(name, new_name, amount, restock_at, order_more, branch):
        with Cursor() as c:
            c.execute("UPDATE raw_material SET name = ?, amount = ?, restock_at = ?, order_more = ? WHERE name = ? AND branch_id = ?", (new_name, amount, restock_at, order_more, name, branch,))

    def material_received(name, amount, order_more, branch):
        with Cursor() as c:
            c.execute("UPDATE raw_material SET amount = ?, order_more = ? WHERE name = ? AND branch_id = ?", (amount, order_more, name, branch,))

    def delete_material(name, branch):
        with Cursor() as c:
            c.execute("DELETE FROM raw_material WHERE name = ? AND branch_id = ?", (name, branch,))


@inv.route('/<branch>/m_inventory/', methods = ["POST","GET"])
@role_required("A", "E")
def m_inventory(branch):
    # Shows entire stock
    inventory = InventoryItem.view_stock(branch)
    materials = RawMaterial.view_materials(branch)
    return render_template('m_inventory.html', inventory = inventory, materials = materials, branch = branch)


@inv.route('/<branch>/create_inventory/', methods = ["POST","GET"])
@role_required("A", "E")
def create_inventory(branch):
    # If details are provided for new inventory item, creates object from InventoryItem class and stores it in database
    if request.method == 'POST':
        name = request.form.get('name')
        amount = max(0, min(100, int(request.form.get('amount'))))
        restock_at = max(0, min(amount, int(request.form.get('restock_at'))))

        item = InventoryItem(name, amount, restock_at)

        InventoryItem.create_stock_item(item, branch)

        flash(f"Inventory item with name: {name}, amount: {amount}, restock at: {restock_at} successfully created.")
        return redirect(url_for('inventory.m_inventory', branch = branch))
    

@inv.route('/<branch>/create_material/', methods = ["POST","GET"])
@role_required("A", "E")
def create_material(branch):
    if request.method == 'POST':
        name = request.form.get('name')
        amount = max(0, min(100, int(request.form.get('amount'))))
        restock_at = max(0, min(amount, int(request.form.get('restock_at'))))
        order_more = "0"

        material = RawMaterial(name, amount, restock_at, order_more)

        RawMaterial.create_material(material, branch)

        flash(f"Inventory material with name: {name}, amount: {amount}, restock at: {restock_at} successfully created.")
        return redirect(url_for('inventory.m_inventory', branch = branch))


@inv.route('/<branch>/update_inventory/<string:item_name>/', methods = ["POST","GET"])
@role_required("A", "E")
def update_inventory(item_name, branch):
    # If details are provided for updated inventory item, uses update_stock to update them in database
    if request.method == 'POST':
        new_name = request.form.get('name')
        amount = max(0, min(100, int(request.form.get('amount'))))
        restock_at = max(0, min(amount, int(request.form.get('restock_at'))))

        InventoryItem.update_stock(item_name, new_name, amount, restock_at, branch)
        return redirect(url_for('inventory.m_inventory', branch = branch))

    # By default, fetches details of an item with specific name to populate update fields with
    item = InventoryItem.view_stock_item(item_name)
    return render_template('update_inventory.html', item = item, branch = branch)


@inv.route('/<branch>/update_material/<string:material_name>/', methods = ["POST","GET"])
@role_required("A", "E")
def update_material(material_name, branch):
    if request.method == 'POST':
        new_name = request.form.get('name')
        amount = max(0, min(100, int(request.form.get('amount'))))
        restock_at = int(request.form.get('restock_at'))
        order_more = int(request.form.get('order_more'))

        if amount <= restock_at:
            order_more = "50"

        RawMaterial.update_material(material_name, new_name, amount, restock_at, order_more, branch)
        return redirect(url_for('inventory.m_inventory', branch = branch))

    material = RawMaterial.view_material(material_name, branch)
    return render_template('update_material.html', material = material, branch = branch)


@inv.route('/<branch>/material_stocked/<string:material_name>/', methods = ["POST","GET"])
@role_required("A", "E")
def material_stocked(material_name, branch):
    material = RawMaterial.view_material(material_name, branch)

    new_amount = int(material['amount']) + int(material['order_more'])
    order_more = "0"

    RawMaterial.material_received(material_name, new_amount, order_more, branch)
    return redirect(url_for('inventory.m_inventory', branch = branch))


@inv.route('/<branch>/delete_inventory/<string:item_name>/', methods = ["POST","GET"])
@role_required("A", "E")
def delete_inventory(item_name, branch):
    if request.method == 'POST':
        InventoryItem.delete_stock_item(item_name, branch)

        flash(f"Inventory item '{item_name}' has been successfully deleted.")
        return redirect(url_for('inventory.m_inventory', branch = branch))
    

@inv.route('/<branch>/delete_material/<string:material_name>/', methods = ["POST","GET"])
@role_required("A", "E")
def delete_material(material_name, branch):
    if request.method == 'POST':
        RawMaterial.delete_material(material_name, branch)

        flash(f"Material '{material_name}' has been successfully deleted.")
        return redirect(url_for('inventory.m_inventory', branch = branch))