CREATE TABLE branch (
 id INTEGER PRIMARY KEY,
 name VARCHAR(50) NOT NULL
);

CREATE TABLE account (
 id INTEGER PRIMARY KEY,
 forename VARCHAR(20) NOT NULL,
 surname VARCHAR(30) NOT NULL,
 security_hash CHAR(77) NOT NULL,
 role CHAR(1) NOT NULL CHECK(role IN('A', 'E', 'U')),
 branch_id INTEGER,
 FOREIGN KEY(branch_id) REFERENCES branch(id)
);

CREATE TABLE menu_category (
 id INTEGER PRIMARY KEY,
 name VARCHAR(50),
 branch_id INTEGER,
 FOREIGN KEY(branch_id) REFERENCES branch(id)
);

CREATE TABLE menu_item (
 id INTEGER PRIMARY KEY,
 category_id INTEGER,
 price FLOAT,
 name VARCHAR(50),
 description VARCHAR(100),
 allergens VARCHAR(10),
 branch_id INTEGER,
 FOREIGN KEY(branch_id) REFERENCES branch(id),
 FOREIGN KEY (category_id) REFERENCES menu_category(id)
);

CREATE TABLE inventory_item (
 id INTEGER PRIMARY KEY,
 name VARCHAR(50),
 amount INTEGER,
 restock_at INTEGER,
 branch_id INTEGER,
 FOREIGN KEY(branch_id) REFERENCES branch(id)
);

CREATE TABLE raw_material (
 id INTEGER PRIMARY KEY,
 name VARCHAR(50),
 amount INTEGER,
 restock_at INTEGER,
 order_more INTEGER,
 branch_id INTEGER,
 FOREIGN KEY(branch_id) REFERENCES branch(id)
);

CREATE TABLE `order` (
 id INTEGER PRIMARY KEY,
 name VARCHAR(40),
 placed_at DATETIME,
 amount_paid FLOAT, -- Store the amount paid for future reports
 status VARCHAR(10),
 branch_id INTEGER,
 table_id INTEGER,
 FOREIGN KEY(table_id) REFERENCES `table`(id),
 FOREIGN KEY(branch_id) REFERENCES branch(id)
);

CREATE TABLE order_item(
 item_id INTEGER,
 order_id INTEGER,
 quantity INTEGER,
 branch_id INTEGER,
 FOREIGN KEY(branch_id) REFERENCES branch(id),
 FOREIGN KEY(order_id) REFERENCES `order`(id)
);

CREATE TABLE reservation (
 id INTEGER PRIMARY KEY,
 `table` INTEGER,
 amount INTEGER,
 name VARCHAR(50),
 datetime DATETIME,
 branch_id INTEGER,
 FOREIGN KEY(branch_id) REFERENCES branch(id),
 FOREIGN KEY('table') REFERENCES 'table'(id)
);

CREATE TABLE `table` (
 id INTEGER PRIMARY KEY,
 capacity INTEGER,
 branch_id INTEGER,
 FOREIGN KEY(branch_id) REFERENCES branch(id)
);

-- Default Values --

insert into branch(id, name) values
(0, "Horizon Restaurants"),
(1, "Birmingham 1"),
(2, "Birmingham 2"),
(3, "Bristol 1"),
(4, "Bristol 2"),
(5, "Cardiff 1"),
(6, "Cardiff 2"),
(7, "Glasgow 1"),
(8, "Glasgow 2"),
(9, "Manchester 1"),
(10, "Manchester 2"),
(11, "Nottingham 1"),
(12, "Nottingham 2"),
(13, "London 1"),
(14, "London 2");

insert into account(forename, surname, role, security_hash, branch_id) values
("emp", "loyee", "A", "$5$rounds=535000$bKnJQj.x4iFQ6Yy6$z.V9RPys8Lx4BVfj2pi.iB1jfxoUeg8wAmCsOFIbhZ9", 3), -- Password is 'admin'
("emp", "loyed", "E", "$5$rounds=535000$efGGd1IgHciolOhF$kqgxs7K4nyH/2dcqi0aBZsYy.e/uiK/ZsbF6qG0PnMA", 5), -- Password is 'cheese'
("cust", "omer", "U", "$5$rounds=535000$EbutSNeTrx/9dwOh$kIRAw31lakZ3PvENvCNagTrSBSnmyF8mrQ9MMhG5qfB", 0); -- Password is 'password'

insert into menu_category(id, name, branch_id) values
(1, "Starters", 3),
(2, "Main", 3),
(3, "Sides", 3),
(4, "Desserts", 3),
(5, "Drinks", 3),
(6, "Starters", 5),
(7, "Main", 5),
(8, "Sides", 5),
(9, "Desserts", 5),
(10, "Drinks", 5);

insert into menu_item(category_id, price, name, description, allergens, branch_id) values
(1, 5, "Starter 1", "Description", "None", 3),
(1, 5, "Starter 2", "Description", "None", 3),
(1, 5, "Starter 3", "Description", "None", 3),
(1, 5, "Starter 4", "Description", "None", 3),
(1, 5, "Starter 5", "Description", "None", 3),
(1, 5, "Starter 6", "Description", "None", 3),
(2, 15, "Main 1", "Description", "None", 3),
(2, 15, "Main 2", "Description", "None", 3),
(2, 15, "Main 3", "Description", "None", 3),
(2, 15, "Main 4", "Description", "None", 3),
(2, 15, "Main 5", "Description", "None", 3),
(2, 15, "Main 6", "Description", "None", 3),
(3, 7.5, "Side 1", "Description", "None", 3),
(3, 7.5, "Side 2", "Description", "None", 3),
(3, 7.5, "Side 3", "Description", "None", 3),
(3, 7.5, "Side 4", "Description", "None", 3),
(3, 7.5, "Side 5", "Description", "None", 3),
(3, 7.5, "Side 6", "Description", "None", 3),
(4, 6, "Dessert 1", "Description", "None", 3),
(4, 6, "Dessert 2", "Description", "None", 3),
(4, 6, "Dessert 3", "Description", "None", 3),
(4, 6, "Dessert 4", "Description", "None", 3),
(4, 6, "Dessert 5", "Description", "None", 3),
(4, 6, "Dessert 6", "Description", "None", 3),
(5, 2.5, "Drink 1", "Description", "None", 3),
(5, 2.5, "Drink 2", "Description", "None", 3),
(5, 2.5, "Drink 3", "Description", "None", 3),
(5, 2.5, "Drink 4", "Description", "None", 3),
(5, 2.5, "Drink 5", "Description", "None", 3),
(5, 2.5, "Drink 6", "Description", "None", 3),
(6, 5, "Starter 1", "Description", "None", 5),
(6, 5, "Starter 2", "Description", "None", 5),
(6, 5, "Starter 3", "Description", "None", 5),
(6, 5, "Starter 4", "Description", "None", 5),
(6, 5, "Starter 5", "Description", "None", 5),
(6, 5, "Starter 6", "Description", "None", 5),
(7, 15, "Main 1", "Description", "None", 5),
(7, 15, "Main 2", "Description", "None", 5),
(7, 15, "Main 3", "Description", "None", 5),
(7, 15, "Main 4", "Description", "None", 5),
(7, 15, "Main 5", "Description", "None", 5),
(7, 15, "Main 6", "Description", "None", 5),
(8, 7.5, "Side 1", "Description", "None", 5),
(8, 7.5, "Side 2", "Description", "None", 5),
(8, 7.5, "Side 3", "Description", "None", 5),
(8, 7.5, "Side 4", "Description", "None", 5),
(8, 7.5, "Side 5", "Description", "None", 5),
(8, 7.5, "Side 6", "Description", "None", 5),
(9, 6, "Dessert 1", "Description", "None", 5),
(9, 6, "Dessert 2", "Description", "None", 5),
(9, 6, "Dessert 3", "Description", "None", 5),
(9, 6, "Dessert 4", "Description", "None", 5),
(9, 6, "Dessert 5", "Description", "None", 5),
(9, 6, "Dessert 6", "Description", "None", 5),
(10, 2.5, "Drink 1", "Description", "None", 5),
(10, 2.5, "Drink 2", "Description", "None", 5),
(10, 2.5, "Drink 3", "Description", "None", 5),
(10, 2.5, "Drink 4", "Description", "None", 5),
(10, 2.5, "Drink 5", "Description", "None", 5),
(10, 2.5, "Drink 6", "Description", "None", 5);

insert into inventory_item(name, amount, restock_at, branch_id) values
("Starter 1", 100, 10, 3),
("Starter 2", 100, 10, 3),
("Starter 3", 100, 10, 3),
("Starter 4", 100, 10, 3),
("Starter 5", 100, 10, 3),
("Starter 6", 100, 10, 3),
("Main 1", 100, 10, 3),
("Main 2", 100, 10, 3),
("Main 3", 100, 10, 3),
("Main 4", 100, 10, 3),
("Main 5", 100, 10, 3),
("Main 6", 100, 10, 3),
("Side 1", 100, 10, 3),
("Side 2", 100, 10, 3),
("Side 3", 100, 10, 3),
("Side 4", 100, 10, 3),
("Side 5", 100, 10, 3),
("Side 6", 100, 10, 3),
("Dessert 1", 100, 10, 3),
("Dessert 2", 100, 10, 3),
("Dessert 3", 100, 10, 3),
("Dessert 4", 100, 10, 3),
("Dessert 5", 100, 10, 3),
("Dessert 6", 100, 10, 3),
("Drink 1", 100, 10, 3),
("Drink 2", 100, 10, 3),
("Drink 3", 100, 10, 3),
("Drink 4", 100, 10, 3),
("Drink 5", 100, 10, 3),
("Drink 6", 100, 10, 3),
("Starter 1", 100, 10, 5),
("Starter 2", 100, 10, 5),
("Starter 3", 100, 10, 5),
("Starter 4", 100, 10, 5),
("Starter 5", 100, 10, 5),
("Starter 6", 100, 10, 5),
("Main 1", 100, 10, 5),
("Main 2", 100, 10, 5),
("Main 3", 100, 10, 5),
("Main 4", 100, 10, 5),
("Main 5", 100, 10, 5),
("Main 6", 100, 10, 5),
("Side 1", 100, 10, 5),
("Side 2", 100, 10, 5),
("Side 3", 100, 10, 5),
("Side 4", 100, 10, 5),
("Side 5", 100, 10, 5),
("Side 6", 100, 10, 5),
("Dessert 1", 100, 10, 5),
("Dessert 2", 100, 10, 5),
("Dessert 3", 100, 10, 5),
("Dessert 4", 100, 10, 5),
("Dessert 5", 100, 10, 5),
("Dessert 6", 100, 10, 5),
("Drink 1", 100, 10, 5),
("Drink 2", 100, 10, 5),
("Drink 3", 100, 10, 5),
("Drink 4", 100, 10, 5),
("Drink 5", 100, 10, 5),
("Drink 6", 100, 10, 5);

insert into `table`(capacity, branch_id) values
(4, 3),
(4, 3),
(4, 3),
(2, 3),
(2, 3),
(2, 3),
(2, 3),
(2, 3),
(2, 3),
(6, 3),
(4, 5),
(4, 5),
(4, 5),
(2, 5),
(2, 5),
(2, 5),
(2, 5),
(2, 5),
(2, 5),
(6, 5);