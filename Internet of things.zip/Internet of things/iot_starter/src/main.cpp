#include <iostream>
#include <string>
#include <cctype> // for toupper

std::string line(std::string message) {
    size_t pos1 = message.find("[");
    size_t pos2 = message.find("]: ");
    if (pos1 != std::string::npos && pos2 != std::string::npos && pos2 + 3 < message.length()) {
        return message.substr(pos2 + 3);
    }
    return ""; // return an empty string if no message found
}

std::string level(std::string message) {
    size_t pos1 = message.find("[");
    size_t pos2 = message.find("]");
    if (pos1 != std::string::npos && pos2 != std::string::npos && pos2 > pos1 + 1) {
        std::string level = message.substr(pos1 + 1, pos2 - pos1 - 1);
        // Convert to uppercase
        for (char &c : level) {
            c = std::toupper(c);
        }
        return level;
    }
    return ""; // return an empty string if no level found
}

std::string reformat(std::string message) {
    std::string logLevel = level(message);
    std::string logMessage = line(message);
    // Convert log level to uppercase
    for (char &c : logLevel) {
        c = std::toupper(c);
    }
    return logMessage + " (" + logLevel + ")";
}

int main() {
    // Test cases
    std::string log1 = "[ERROR]: Invalid operation";
    std::string log2 = "[INFO]: Process completed successfully";
    std::string log3 = "[WARNING]: Resource usage high";

    // Test the line function
    std::cout << "Test 1: " << line(log1) << std::endl; // Should print "Invalid operation"
    std::cout << "Test 2: " << line(log2) << std::endl; // Should print "Process completed successfully"
    std::cout << "Test 3: " << line(log3) << std::endl; // Should print "Resource usage high"

    // Test the level function
    std::cout << "Test 4: " << level(log1) << std::endl; // Should print "ERROR"
    std::cout << "Test 5: " << level(log2) << std::endl; // Should print "INFO"
    std::cout << "Test 6: " << level(log3) << std::endl; // Should print "WARNING"

    // Test the reformat function
    std::cout << "Test 7: " << reformat(log1) << std::endl; // Should print "Invalid operation (ERROR)"
    std::cout << "Test 8: " << reformat(log2) << std::endl; // Should print "Process completed successfully (INFO)"
    std::cout << "Test 9: " << reformat(log3) << std::endl; // Should print "Resource usage high (WARNING)"

    return 0;
}