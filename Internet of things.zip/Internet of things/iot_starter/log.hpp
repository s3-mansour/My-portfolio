#pragma once

#include <string>
#include <fstream>

class Log {
private:
    std::ifstream logFile;
    std::ofstream outFile; // For appending
    std::string currentLine;
    std::string filename; // To store the name of the log file
public:
    Log();
    ~Log();
    bool create(const std::string& filename);
    bool open(const std::string& filename);
    bool append(const std::string& line);
    bool clear(); // New method to clear the contents of the log file
    bool next();
    std::string line();
    std::string level();
    std::string reformat();
};
