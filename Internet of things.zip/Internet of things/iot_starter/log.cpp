#include "log.hpp"

Log::Log() {
    // Constructor does very little
}

Log::~Log() {
    // Destructor closes the log file if it was opened correctly
    if (logFile.is_open()) {
        logFile.close();
    }
}

bool Log::create(const std::string& filename) {
    logFile.open(filename);
    return logFile.is_open();
}

bool Log::open(const std::string& filename) {
    logFile.open(filename);
    return logFile.is_open();
}

bool Log::append(const std::string& line) {
    if (outFile.is_open()) {
        outFile << line << std::endl;
        return true;
    }
    return false;
}

bool Log::clear() {
    if (outFile.is_open()) {
        outFile.close();
        outFile.open(filename, std::ofstream::out | std::ofstream::trunc);
        return outFile.is_open();
    }
    return false;
}

bool Log::next() {
    if (std::getline(logFile, currentLine)) {
        return true;
    }
    return false;
}

std::string Log::line() {
    return currentLine;
}

std::string Log::level() {
    // Assuming log level is the first word in the line
    std::string delimiter = " ";
    size_t pos = currentLine.find(delimiter);
    if (pos != std::string::npos) {
        return currentLine.substr(0, pos);
    }
    return ""; // Return empty string if delimiter is not found
}

std::string Log::reformat() {
    // Example reformatting: prepend "Reformatted: " to the line
    return "Reformatted: " + currentLine;
}
