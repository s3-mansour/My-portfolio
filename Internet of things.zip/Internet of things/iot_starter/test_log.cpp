#include "log.hpp"
#include "./simpletest/simpletest.h"


char const * groups[] = {
    "Log",
};

DEFINE_TEST_G(LogCreationTest, Log)
{
    Log log;
    bool success = log.open("./log.in");
    TEST_MESSAGE(success != true, "Failed to open log file!!!!");
}

DEFINE_TEST_G(LogReadingTest, Log)
{
    Log log;
    bool success = log.open("./log.in");
    TEST_MESSAGE(success == true, "Failed to open log file for reading!!!!");

    success = log.next();
    TEST_MESSAGE(success != true, "Failed to read log file!!!!");

    std::string line = log.line();
    TEST_MESSAGE(line.compare("Invalid operation") == 0, "Expecting 'Invalid operation'!!!!");
}

DEFINE_TEST_G(LogAppendingTest, Log)
{
    Log log;
    bool success = log.open("./log.out"); // Create a new log file
    TEST_MESSAGE(success == true, "Failed to create log file for appending!!!!");

    // Append some lines to the log file
    success = log.append("First line");
    TEST_MESSAGE(success == true, "Failed to append to log file!!!!");

    success = log.append("Second line");
    TEST_MESSAGE(success == true, "Failed to append to log file!!!!");

    success = log.append("Third line");
    TEST_MESSAGE(success == true, "Failed to append to log file!!!!");

    // Now read the lines back and check if they match
    success = log.open("./log.in"); // Open the log file for reading
    TEST_MESSAGE(success == true, "Failed to open log file for reading!!!!");

    // Check the first line
    success = log.next();
    TEST_MESSAGE(success == true, "Failed to read log file!!!!");
    std::string line = log.line();
    TEST_MESSAGE(line.compare("First line") == 0, "Unexpected line read from log file!!!!");

    // Check the second line
    success = log.next();
    TEST_MESSAGE(success == true, "Failed to read log file!!!!");
    line = log.line();
    TEST_MESSAGE(line.compare("Second line") == 0, "Unexpected line read from log file!!!!");

    // Check the third line
    success = log.next();
    TEST_MESSAGE(success == true, "Failed to read log file!!!!");
    line = log.line();
    TEST_MESSAGE(line.compare("Third line") == 0, "Unexpected line read from log file!!!!");

    // Ensure no more lines are present
    success = log.next();
    TEST_MESSAGE(success != true, "Unexpected line read from log file!!!!");
}
DEFINE_TEST_G(LogLevelExtractionTest, Log)
{
    Log log;
    bool success = log.open("./log.in");
    TEST_MESSAGE(success == true, "Failed to create log file for log level extraction test case!!!!");

    // Append some lines with different log levels to the log file
    success = log.append("INFO: Informational message");
    TEST_MESSAGE(success == true, "Failed to append to log file for log level extraction test case!!!!");

    success = log.append("ERROR: Error message");
    TEST_MESSAGE(success == true, "Failed to append to log file for log level extraction test case!!!!");

    success = log.append("WARNING: Warning message");
    TEST_MESSAGE(success == true, "Failed to append to log file for log level extraction test case!!!!");

    // Open the log file and read the lines back to extract log levels
    success = log.open("./log.in");
    TEST_MESSAGE(success == true, "Failed to open log file for reading for log level extraction test case!!!!");

    // Check the log levels
    success = log.next(); // Read the first line
    TEST_MESSAGE(success == true, "Failed to read log file for log level extraction test case!!!!");
    std::string level = log.level();
    TEST_MESSAGE(level.compare("INFO:") == 0, "Incorrect log level extracted from log file for INFO message!!!!");

    success = log.next(); // Read the second line
    TEST_MESSAGE(success == true, "Failed to read log file for log level extraction test case!!!!");
    level = log.level();
    TEST_MESSAGE(level.compare("ERROR:") == 0, "Incorrect log level extracted from log file for ERROR message!!!!");

    success = log.next(); // Read the third line
    TEST_MESSAGE(success == true, "Failed to read log file for log level extraction test case!!!!");
    level = log.level();
    TEST_MESSAGE(level.compare("WARNING:") == 0, "Incorrect log level extracted from log file for WARNING message!!!!");

    // Ensure no more lines are present
    success = log.next();
    TEST_MESSAGE(success != true, "Unexpected line read from log file for log level extraction test case!!!!");
}

DEFINE_TEST_G(LogClearingTest, Log)
{
    Log log;
    bool success = log.open("./log.in");
    TEST_MESSAGE(success == true, "Failed to create log file for clearing!!!!");

    // Append some lines to the log file
    success = log.append("First line");
    TEST_MESSAGE(success == true, "Failed to append to log file!!!!");

    success = log.append("Second line");
    TEST_MESSAGE(success == true, "Failed to append to log file!!!!");

    success = log.append("Third line");
    TEST_MESSAGE(success == true, "Failed to append to log file!!!!");

    // Clear the log file
    success = log.clear();
    TEST_MESSAGE(success == true, "Failed to clear log file!!!!");

    // Ensure the log file is empty
    success = log.open("./log.in");
    TEST_MESSAGE(success == true, "Failed to open log file for reading!!!!");
    success = log.next(); // Try to read the first line
    TEST_MESSAGE(success != true, "Unexpected line read from log file after clearing!!!!");
}

int main() {
    bool pass = true;
    for (auto group : groups) {
        pass &= TestFixture::ExecuteTestGroup(group, TestFixture::Verbose);
    }
    return pass ? 0 : 1;
}
