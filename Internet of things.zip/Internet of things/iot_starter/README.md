## Task 1: Setting Up the Development Environment and Initial Project Configuration

### Objective
The goal of this task is to establish a development environment conducive to working on Internet of Things (IoT) projects using C++17 and Make for build automation. This involves connecting to a remote server, forking and cloning a starter project repository, and familiarizing oneself with the project's structure and Makefile configuration.

### Steps
1.**Fork and Clone the Repository**: Fork the starter project repository located at `https://gitlab.uwe.ac.uk/br‑gaster/iot_starter.git`. After forking, clone your forked version of the repository to your local workspace. This step provides you with a personal copy of the project to work on.

**Forking the project**

![Local Image](./worksheet1_images/Picture1.png "Local image in the repository")

**Cloning it**

![Local Image](./worksheet1_images/Picture2.png "Local image in the repository")

2. **Explore the Project Structure**: Change into the `iot_starter` directory and use the `ls` command to list the initial contents of the directory. You should find a `Makefile` and `main.cpp`, which are the foundation of the starter project. The `Makefile` contains instructions for building the `main.cpp` source file into an executable application within a `build` directory, which will be created during the build process.

3. **Build the Project**: Execute the `make` command to compile `main.cpp` into an executable named `app` located in the `build` directory. This demonstrates the Makefile's capability to automate the build process, including directory creation.

4. **Run the Application**: Test the built application by running `./build/app` directly or using `make run`. The application should output "Good day", indicating that it has been setup and executed successfully.

**Testing the "ls" and "make" commands**

![Local Image](./worksheet1_images/Picture3.png "Local image in the repository")

**Running the app successfully in the build directory**

![Local Image](./worksheet1_images/Picture4.png "Local image in the repository")

### Conclusion
Completing this task ensures that you have a properly configured development environment on the remote server, along with a foundational understanding of how to build and run C++ applications using Make. This setup is crucial for efficiently tackling subsequent tasks in the module that focus on IoT application development with C++17.
-----------------------------------------------------------------

## Part 1: Extracting Messages from Log Lines

### Function Implementation
The `std::string line(std::string message)` function is designed to parse log lines and extract the message part of the log. It achieves this by identifying the positions of the opening bracket `[` and the closing sequence `]: ` within the input string. The function ensures that these markers are present and correctly positioned before proceeding to extract the substring that constitutes the message.

### Code Snippet
```cpp
std::string line(std::string message) {
    size_t pos1 = message.find("[");
    size_t pos2 = message.find("]: ");
    if (pos1 != std::string::npos && pos2 != std::string::npos && pos2 + 3 < message.length()) {
        return message.substr(pos2 + 3);
    }
    return ""; // return an empty string if no message found
}
```

### Logic
- The function searches for the first occurrence of the opening bracket `[` and the end of the log level indicator `]: `.
- It then checks if both indicators are found and ensures that there is a message after the `]: ` sequence.
- If the conditions are satisfied, the function returns the substring starting just after the `]: ` sequence, which is the message part.
- If no valid log message pattern is found, the function returns an empty string to signify that the message could not be extracted.

### Testing
To verify the functionality, the `main` function has been extended with test cases that process various log lines of different log levels (INFO, WARNING, ERROR). Here are the test cases and their expected outputs:

```cpp
// Test cases
std::string log1 = "[ERROR]: Invalid operation";
std::string log2 = "[INFO]: Process completed successfully";
std::string log3 = "[WARNING]: Resource usage high";

// Test the line function
std::cout << "Test 1: " << line(log1) << std::endl; // Should print "Invalid operation"
std::cout << "Test 2: " << line(log2) << std::endl; // Should print "Process completed successfully"
std::cout << "Test 3: " << line(log3) << std::endl; // Should print "Resource usage high"
```

### Output Confirmation
As demonstrated in the screenshot of the terminal output, all test cases have returned the correct messages, confirming that the `line` function is functioning as intended.

![Local Image](./worksheet1_images/Picture5.png "Local image in the repository")

---


## Part 2: Extracting Log Levels from Log Lines

### Function Implementation
The `std::string level(std::string message)` function extracts the log level from a formatted log line and converts it to uppercase. The log level is assumed to be enclosed within square brackets `[ ]` at the beginning of the log line.

### Code Snippet
```cpp
std::string level(std::string message) {
    size_t pos1 = message.find("[");
    size_t pos2 = message.find("]");
    if (pos1 != std::string::npos && pos2 != std::string::npos && pos2 > pos1 + 1) {
        std::string level = message.substr(pos1 + 1, pos2 - pos1 - 1);
        // Convert to uppercase
        for (char &c : level) {
            c = std::toupper(c);
        }
        return level;
    }
    return ""; // return an empty string if no level found
}
```

### Logic
- The function identifies the start and end indices of the log level by finding the `[` and `]` characters.
- It extracts the log level as a substring of the message string.
- Each character in the extracted log level is converted to uppercase.

### Testing
The following test cases check if the function correctly identifies and converts log levels to uppercase:

```cpp
// Test cases
std::string log1 = "[ERROR]: Invalid operation";
std::string log2 = "[INFO]: Process completed successfully";
std::string log3 = "[WARNING]: Resource usage high";

// Test the level function
std::cout << "Test 4: " << level(log1) << std::endl; // Should print "ERROR"
std::cout << "Test 5: " << level(log2) << std::endl; // Should print "INFO"
std::cout << "Test 6: " << level(log3) << std::endl; // Should print "WARNING"
```

### Output Confirmation
The terminal output, as shown in the screenshot, confirms that the function `level` returns the correct uppercase log levels for all the test cases provided.

![Local Image](./worksheet1_images/Picture6.png "Local image in the repository")



```markdown
## Part 3: Reformatting Log Lines

### Function Implementation
The `std::string reformat(std::string message)` function reformats a given log line by placing the message content first and appending the log level at the end within parentheses. This reformatting makes the log message the primary focus, followed by its level of severity, which can enhance readability in certain contexts.

### Code Snippet
```cpp
std::string reformat(std::string message) {
    std::string logLevel = level(message);
    std::string logMessage = line(message);
    // Convert log level to uppercase
    for (char &c : logLevel) {
        c = std::toupper(c);
    }
    return logMessage + " (" + logLevel + ")";
}
```

### Logic
- The function utilizes the previously implemented `level` and `line` functions to extract the log level and message, respectively.
- It converts the log level to uppercase for consistent formatting.
- The log message is concatenated with the log level, which is surrounded by parentheses, to create the reformatted log line.

### Testing
The functionality is demonstrated through the following test cases which reformat different log lines and output them:

```cpp
// Test cases
std::string log1 = "[ERROR]: Invalid operation";
std::string log2 = "[INFO]: Process completed successfully";
std::string log3 = "[WARNING]: Resource usage high";

// Test the reformat function
std::cout << "Test 7: " << reformat(log1) << std::endl; // Should print "Invalid operation (ERROR)"
std::cout << "Test 8: " << reformat(log2) << std::endl; // Should print "Process completed successfully (INFO)"
std::cout << "Test 9: " << reformat(log3) << std::endl; // Should print "Resource usage high (WARNING)"
```

### Output Confirmation
The screenshot of the terminal output confirms the correct reformatting of log lines by the `reformat` function, with the message taking precedence and the log level in uppercase following in parentheses.

![Local Image](./worksheet1_images/Picture7.png "Local image in the repository")

## Task 2: Advancing to a Log Processing Class

### Overview
Building on the individual log line manipulation functions from Task 1, Task 2 involves the development of a `Log` class designed for comprehensive log file processing. This class integrates reading, writing, and formatting capabilities, allowing for efficient and organized log file management.

### Class Design and Implementation
The `Log` class is defined in `log.hpp` and implemented in `log.cpp`. It encapsulates the core functionalities necessary for log processing, including file handling and log entry extraction and manipulation. The class interface in `log.hpp` outlines the constructors, destructors, and methods for log file operations:

```cpp
class Log {
    // ...
    // Constructor, destructor, and methods as previously described.
    // ...
};
```

In `log.cpp`, the constructor initializes resources, and the destructor ensures clean-up of open file streams. Key methods include `create` for opening new log files, `next` for reading log lines, and `reformat` for modifying the format of log entries:

```cpp
bool Log::create(const std::string& filename) {
    // ...
}
// Other method implementations...
```

### Main Application
The `main_part2.cpp` file tests the `Log` class's capabilities by opening a log file, reading its contents, and displaying reformatted log entries:

```cpp
int main() {
    // ...
    // Testing log file creation, reading, and processing.
    // ...
}
```

### Makefile Configuration
The Makefile is updated to compile and link the `Log` class with the application. It now includes the `log.cpp` source and its corresponding header file:

```makefile
CPP_SOURCES = ./log.cpp ./main_part2.cpp
CPP_HEADERS = ./log.hpp
```

Targets within the Makefile manage the building of the application and the clean-up process. The new `app2` target is set up to compile `main_part2.cpp`:

```makefile
all: $(BUILD_DIR)/$(APP) $(BUILD_DIR)/$(APP2)

$(BUILD_DIR)/$(APP2): main_part2.cpp $(OBJECTS) Makefile
    // ...
```

The testing section of your `readme.md` can be detailed with an explanation that highlights the testing process showcased in the provided screenshot. Here's how you can elaborate on this:

---

### Testing the Log Class

A rigorous testing procedure is essential to validate the functionality of the `Log` class. The `main_part2.cpp` serves as the test harness for the class, exemplifying the usage pattern and confirming the expected behavior of each method.

The testing procedure involves the following steps:
1. **Initialization**: An instance of the `Log` class is instantiated.
2. **File Opening**: The `create` method is invoked to open a pre-existing log file, `log.in`, and a successful open operation is indicated by a console message.
3. **Log Reading**: A loop iterates over the log entries using the `next` method. For each log entry:
   - The original log line is output to the console, demonstrating the `line` method.
   - The log level is extracted and printed, showcasing the `level` method's ability to correctly identify the log severity.
   - A reformatted version of the log line is produced and displayed, validating the `reformat` method's operation.

In the provided screenshot, we see this testing procedure in action. The console output confirms that each step of the log file processing is functioning as intended. The output includes:
- Successful feedback on log file opening.
- Accurate reading and printing of log messages.
- Correct extraction of log levels.
- The desired reformatting of log entries.

This indicates that the `Log` class can effectively handle a log file, perform operations on individual log entries, and serve as a robust tool for log analysis.

### Screenshot Confirmation

The accompanying screenshot from the test environment not only confirms the successful execution of these tests but also provides a visual checkpoint for code reviewers and collaborators. It illustrates the class's methods in action, providing real-world evidence of the code’s efficacy.

![Local Image](./worksheet1_images/Picture8.png "Local image in the repository")

---

---

## Task 3: Ensuring Class Integrity with Unit Testing

### Purpose of Task 3
The primary focus of Task 3 is to establish a robust testing framework for the `Log` class using `simpletest`. This step validates each method within the class, ensuring that the functionality aligns with expected behaviors and that the class is reliable for deployment.

### Setting Up the Testing Framework
Integration with the `simpletest` framework begins with its addition as a submodule, providing a solid foundation for unit testing. The following git command is used to integrate the framework into the project:

```shell
git submodule add https://github.com/kudaba/simpletest.git
```

![Local Image](./worksheet1_images/Picture9.png "Local image in the repository")

### Writing Comprehensive Test Cases
The suite of unit tests is encapsulated within `test_log.cpp`. This suite encompasses various aspects of the `Log` class's functionality:

- Creating a new log file (`LogCreationTest`).
- Reading entries from a log file (`LogReadingTest`).
- Appending new entries to a log (`LogAppendingTest`).
- Extracting and verifying log levels (`LogLevelExtractionTest`).
- Clearing the contents of a log file (`LogClearingTest`).

Each test is carefully structured to utilize assertions that validate the correctness of the `Log` class methods:

```cpp
DEFINE_TEST_G(LogCreationTest, Log) {
    // ...
}
DEFINE_TEST_G(LogReadingTest, Log) {
    // ...
}
// Additional test cases...
```

### Makefile Adjustments for Task 3
The Makefile has been tailored to include a new build target `app3` specifically for the unit tests. The relevant section to compile and link the test executable is:

```makefile
$(BUILD_DIR)/$(APP3): test_log.cpp $(OBJECTS) Makefile
    // ...
```

### Test Execution and Analysis
Tests are conducted via the `run3` target in the Makefile. Upon invocation, it triggers the compilation of the test cases and outputs the results to the terminal, which is captured in the screenshot:

![Testing Image](./worksheet1_images/Picture10.png "Local image in the repository")

The screenshot display the detailed results of each test case, indicating which tests passed and which ones failed. This output is critical for developers to fine-tune the `Log` class, ensuring its reliability and functionality.

### Conclusion 
Task 3 culminates the development phase with a series of rigorous unit tests. It not only solidifies the confidence in the `Log` class's capabilities but also sets a precedent for continuous integration and development practices. The documentation of this task, supported by code snippets and test outcomes, becomes a testament to the quality assurance process of the project.

---


