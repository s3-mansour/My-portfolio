#include "./log.hpp"
#include <iostream>
int main() {
    // Create an instance of the Log class
    Log log;

    // Attempt to open a log file
    std::string filename = "log.in";
    if (log.create(filename)) {
        std::cout << "Log file opened successfully!" << std::endl;

        // Read and process log messages
        while (log.next()) {
            // Get the current log message
            std::string message = log.line();
            std::cout << "Log Message: " << message << std::endl;

            // Extract and display the log level
            std::string logLevel = log.level();
            std::cout << "Log Level: " << logLevel << std::endl;

            // Reformat the log message
            std::string reformattedMessage = log.reformat();
            std::cout << "Reformatted Message: " << reformattedMessage << std::endl;
        }
    } else {
        std::cerr << "Failed to open log file!" << std::endl;
        return 1;
    }

    return 0;
}
