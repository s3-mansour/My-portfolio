#include <util.hpp>
#include <iot/socket.hpp>
#include <arpa/inet.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>

int main() {
    // Set server IP address
    uwe::set_ipaddr("192.167.1.8");

    // Create a socket for the server
    uwe::socket sock{AF_INET, SOCK_DGRAM, 0};

    // Define server address and port
    struct sockaddr_in server_addr;
    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(8877);
    inet_pton(AF_INET, uwe::get_ipaddr().c_str(), &server_addr.sin_addr);

    // Bind the socket
    sock.bind((struct sockaddr*)&server_addr, sizeof(server_addr));

    // Buffer to store the incoming packet data
    char buffer[1024];

    // Structure to hold the client address
    struct sockaddr_in client_addr;
    size_t client_addr_len = sizeof(client_addr); // Corrected type to size_t

    // Loop to receive messages
    while (true) {
        ssize_t message_len = sock.recvfrom(
            buffer, sizeof(buffer) - 1, 0,
            (struct sockaddr*)&client_addr, &client_addr_len); // Corrected type for client_addr_len

        if (message_len > 0) {
            // Null-terminate the received data
            buffer[message_len] = '\0';

            // Display the received message
            printf("Received message: '%s' from %s:%d\n",
                   buffer,
                   inet_ntoa(client_addr.sin_addr),
                   ntohs(client_addr.sin_port));
        }
    }

    return 0;
}
