## Task 1: Mastering UDP Sockets for Inter-Process Communication

### Introduction
Understanding the intricacies of network communication is pivotal for modern applications, especially within the realm of IoT. This task is centered on using UDP sockets to enable message transmission between a client and a server process, laying the groundwork for a future echo client-server model.
### Creating and cloning a new repository

![creating new project image](./worksheet2_images/Picture4.png)

![cloning  image](./worksheet2_images/Picture5.png)

### The UDP Client Implementation (`udp_client.cpp`)
In the client implementation, the key steps include setting up the client's IP address, creating a socket with the appropriate address family and type, and sending a crafted message to the server's known IP address and port number:

```cpp
uwe::set_ipaddr("192.167.1.7"); // Client IP
const int server_port = 8877;    // Server port
const char* server_name = "192.167.1.8"; // Server IP
// ... (Additional setup code)
uwe::socket sock{AF_INET, SOCK_DGRAM, 0}; // UDP socket creation
// ... (Bind socket and send message)
```

This code establishes the client's environment, defining where and how it should communicate with the server.

### Testing the client:
![sending message image](./worksheet2_images/Picture1.png)

The output in  screenshot shows that i have successfully run the iotdump command and it has decoded the packet data. It displays the IP addresses for the source and destination (192.168.1.7 and 192.168.1.8 respectively) and the message content which is **This is an IOT packet**.
This output indicates that the message was successfully sent from your client and that the packet file was correctly created and contains the expected data. The ** around the message seems to be just a way the iotdump utility highlights the content of the message.
### The UDP Server Implementation (`udp_server.cpp`)
The server side sets up to listen for incoming UDP packets. After initializing its own socket, the server binds to its designated port and awaits messages:

```cpp
uwe::set_ipaddr("192.167.1.8"); // Server IP
// ... (Additional setup code)
uwe::socket sock{AF_INET, SOCK_DGRAM, 0}; // Server socket creation
// ... (Binding the socket)
// Receive messages loop
while (true) {
    // ... (Receiving message and printing it out)
}
```

The server's loop runs indefinitely, processing any incoming messages and extracting the sender's details to display on the console.

### Verification Through Testing
Testing is a critical component, ensuring that messages are not only sent by the client but also received correctly by the server. Console outputs provide clear evidence of successful communication between the client and the server.


![running both client and server](./worksheet2_images/Picture2.png)

successfully compiled the udp_client with the make udp_client command, ran the udp_client executable, and then in the other terminal window, the udp_server is receiving the messages as expected. The output shows that the server received the message "This is an IOT packet" from the client, which is exactly what you want in this step.

![running both client and server](./worksheet2_images/Picture3.png)


then changed the message to **hello world** and recompiled the program and it worked successfully.

---

## Makefile Configuration for UDP Client-Server Compilation

### Overview
The Makefile provided orchestrates the build process for the UDP client and server applications. It specifies the compiler settings, compilation flags for modern C++ support and debugging, and linker flags to locate and link with the required IoT library and threads.

### Compiler Settings
```make
CXX=g++
```
The `CXX` variable defines the C++ compiler to be used, which is set to `g++` by default. It can be changed to `clang++` or any other compliant compiler if preferred.

### Compilation Flags
```make
CXXFLAGS=-std=c++17 -g -I/opt/iot/include
```
The `CXXFLAGS` are the options passed to the compiler, which in this case enables C++17 features, includes debugging information with `-g`, and specifies where to find the IoT header files with `-I/opt/iot/include`.

### Linker Flags
```make
LDFLAGS=-L/opt/iot/lib -liot -lpthread -no-pie
```
The `LDFLAGS` direct the linker to the location of the IoT static library using `-L/opt/iot/lib` and instruct it to link against the IoT library `-liot` and the pthread library for threading support `-lpthread`. The `-no-pie` option is used to disable Position Independent Executable generation, which is sometimes required for certain linking contexts.

### Targets and Build Rules
```make
CLIENT=udp_client
SERVER=udp_server
```
Two target variables, `CLIENT` and `SERVER`, are declared to hold the names of the resulting executable files.

```make
all: $(CLIENT) $(SERVER)
```
The default `all` target is defined to build both the client and server applications.

```make
$(CLIENT): udp_client.cpp
	$(CXX) $(CXXFLAGS) -o $(CLIENT) udp_client.cpp $(LDFLAGS)

$(SERVER): udp_server.cpp
	$(CXX) $(CXXFLAGS) -o $(SERVER) udp_server.cpp $(LDFLAGS)
```
The build rules for the client and server executables specify the dependencies on their respective source files and the commands to compile them, combining the compiler flags and linker flags set earlier.


### Linking It All Together
This Makefile ties together the necessary components for building the UDP client and server. It is tuned to the specific needs of the IoT library and provides a seamless build experience, whether you're compiling on your local machine or a remote server environment. By just invoking `make` without arguments, both the client and server are compiled, ready to be run and tested for UDP communication capabilities.

--- 
### overview

The completion of Task 1 in Worksheet 2 signifies a foundational step into the realm of UDP networking within IoT contexts. It involves hands-on experience in implementing a UDP client and server, navigating through the nuances of setting IP addresses, port numbers, and creating sockets for message transmission.

This task has cemented the understanding of the UDP protocol's stateless nature and its applicability in situations where speed trumps reliability. The role of a well-crafted Makefile is also highlighted, demonstrating its effectiveness in simplifying the compilation process and facilitating a focus on the development of robust network applications.

Moving forward, the insights and competencies gained will act as a cornerstone for confronting more advanced networking challenges, fostering innovation in the ever-expanding domain of the Internet of Things.

