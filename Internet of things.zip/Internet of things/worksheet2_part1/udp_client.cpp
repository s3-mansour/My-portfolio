#include <util.hpp>
#include <iot/socket.hpp>
#include <arpa/inet.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>
int main() {
    // Set client IP address
    uwe::set_ipaddr("192.167.1.7");

    const int server_port = 8877;
    const char* server_name = "192.167.1.8";
    // Initialize server address structure
    sockaddr_in server_address;
    memset(&server_address, 0, sizeof(server_address));
    server_address.sin_family = AF_INET; // Set to use IPv4 addresses

    // Convert server IP address from text to binary form and set it
    inet_pton(AF_INET, server_name, &server_address.sin_addr);

    // Convert server port number to network byte order and set it
    server_address.sin_port = htons(server_port);
    
    // Create a UDP socket
    uwe::socket sock{AF_INET, SOCK_DGRAM, 0};
    
    // port for client
    const int client_port = 1001;
    // socket address used for the client
    struct sockaddr_in client_address;
    memset(&client_address, 0, sizeof(client_address));
    client_address.sin_family = AF_INET;
    client_address.sin_port = htons(client_port);

    inet_pton(AF_INET, uwe::get_ipaddr().c_str(), &client_address.sin_addr);
    sock.bind((struct sockaddr *)&client_address, sizeof(client_address));
    
    // data that will be sent to the server
    std::string message = "iottt";
    
    // send data
    int len = sock.sendto(
        message.c_str(), message.length(), 0,
        (sockaddr*)&server_address, sizeof(server_address));

    return 0;
}
