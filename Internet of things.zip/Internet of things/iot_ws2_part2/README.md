
## Task1
Task 1 dives into the server-side mechanics of a chat application, necessitating a nuanced understanding of socket programming to facilitate real-time communication. This task emphasizes implementing key server functionalities to manage user interactions—specifically joining the chat, sending direct messages, and handling server exits. Let's delve into the intricacies of these implementations:

### Implementation of `handle_join`

This function orchestrates user entry into the chat server, ensuring unique usernames and broadcasting the event to all current participants.

```cpp
void handle_join(online_users& users, std::string username, struct sockaddr_in& client_address, uwe::socket& sock, bool& exit_loop) {
    if (users.find(username) != users.end()) {
        handle_error(ERR_USER_ALREADY_ONLINE, client_address, sock, exit_loop);
    } else {
        auto* addr = new sockaddr_in(client_address);
        users[username] = addr;
        auto confirmationMsg = chat::jack_msg(); // Acknowledgment message
        sock.sendto(reinterpret_cast<const char*>(&confirmationMsg), sizeof(confirmationMsg), 0, (sockaddr*)&client_address, sizeof(client_address));
        for (const auto& user : users) {
            if (user.first != username) {
                auto broadcastMsg = chat::broadcast_msg("Server", username + " has joined the chat.");
                sock.sendto(reinterpret_cast<const char*>(&broadcastMsg), sizeof(broadcastMsg), 0, (sockaddr*)user.second, sizeof(sockaddr_in));
            }
        }
        handle_list(users, "", client_address, sock, exit_loop);
    }
}
```

- **Error Handling**: Detects if the username is already in use and sends an error response accordingly.
- **User Addition**: If the username is unique, it adds the user to the `online_users` map and acknowledges the successful join.
- **Broadcast Notification**: Notifies all existing users about the new user joining the chat.

### Implementation of `handle_directmessage`

Facilitates sending messages directly from one user to another, bypassing the broadcast mechanism.

```cpp
void handle_directmessage(online_users& users, std::string sender_username, std::string message, struct sockaddr_in& sender_address, uwe::socket& sock, bool& exit_loop) {
    auto separator_pos = message.find(':');
    std::string recipient_username = message.substr(0, separator_pos);
    std::string actual_message = message.substr(separator_pos + 1);
    auto recipient_it = users.find(recipient_username);
    if (recipient_it != users.end()) {
        auto dm_msg = chat::dm_msg(sender_username, actual_message);
        sock.sendto(reinterpret_cast<const char*>(&dm_msg), sizeof(dm_msg), 0, (sockaddr*)recipient_it->second, sizeof(sockaddr_in));
    }
    // Optional: Error handling or sender notification for unknown recipient.
}
```

- **Recipient Identification**: Extracts the recipient's username and the intended message.
- **Message Dispatch**: Constructs a direct message and sends it to the specified recipient.

### Implementation of `handle_exit`

Manages server shutdown commands, ensuring all users are properly notified and resources are cleaned up.

```cpp
void handle_exit(online_users& users, struct sockaddr_in& client_address, uwe::socket& sock, bool& exit_loop) {
    auto exit_msg = chat::exit_msg();
    for (auto& user : users) {
        sock.sendto(reinterpret_cast<const char*>(&exit_msg), sizeof(exit_msg), 0, (sockaddr*)user.second, sizeof(struct sockaddr_in));
        delete user.second; // Freeing dynamically allocated memory.
        user.second = nullptr;
    }
    users.clear();
    exit_loop = true; // Triggers server shutdown.
}
```

- **Broadcast Exit**: Sends an exit command to all connected clients to initiate their disconnection.
- **Resource Cleanup**: Ensures no memory leaks by deallocating memory and clearing the users map.

These functions collectively enhance the server's ability to manage chat room dynamics effectively, addressing user registration, personalized communication, and orderly shutdown procedures. Implementing these features requires a thorough grasp of network programming principles, alongside proficiency in handling concurrent operations within a server-client architecture.

## Task2

Task 2 advances into developing the client-side logic of the chat application. It focuses on ensuring the chat client can not only send messages to the server but also handle incoming messages from it. This task introduces a multi-threaded approach to manage user interactions and network communications simultaneously, enhancing the client's responsiveness and functionality.

### Key Objectives:

- **Concurrent Handling of UI and Network Messages**: Implement threading to allow the chat client to process user inputs and server messages concurrently, preventing one process from blocking the other.
- **Message Sending and Receiving**: Equip the chat client with the ability to send user-generated messages to the server and display incoming messages from other users in real-time.

### Core Components:

1. **Thread Creation and Channel Communication**:
   Utilize C++ threads to separate the handling of UI inputs and network messages. Establish channels for safe, thread-aware communication between the main thread, UI thread, and network message receiver thread.

2. **Receiver Thread Implementation**:
   Craft a receiver thread function responsible for listening to and processing messages from the server. This involves parsing message content and updating the client UI accordingly.

3. **UI Message Processing**:
   In the main thread, handle messages received from the UI (user inputs) and coordinate actions such as sending chat messages or commands to the server.

### Client Implementation Overview

The client code for the chat application orchestrates a seamless interaction between users and the chat server, leveraging modern C++ features, the IoT socket API, and a robust multithreading architecture. Let's dissect the key functionalities and their implementation:

### 1. **Command Conversion with `to_type` Function**

This function maps user input commands to the corresponding chat protocol commands, facilitating the client's ability to send various types of messages to the server:

```cpp
chat::chat_type to_type(std::string cmd) {
    switch(string_to_int(cmd.c_str())) {
        case string_to_int("dm"): return chat::DIRECTMESSAGE;
        case string_to_int("list"): return chat::LIST;
        case string_to_int("leave"): return chat::LEAVE;
        case string_to_int("exit"): return chat::EXIT;
        default: return chat::UNKNOWN;
    }
}
```

- **Usage**: It processes commands like "leave" and "dm" (direct message), converting them into protocol-specific message types.

### 2. **Message Reception with `make_receiver`**

A dedicated thread for receiving messages ensures the client can handle incoming data without interrupting the user interface:

```cpp
std::pair<std::thread, Channel<chat::chat_message>> make_receiver(uwe::socket* sock) {
    // Thread logic to continuously receive and process messages
}
```

- **Functionality**: This thread listens for messages from the server, decodes them, and forwards them to the main application thread for further action.

### 3. **Initializing Client and Sending Join Request**

The main function initializes the client's connection to the server and handles the user's entry into the chat room:

```cpp
int main(int argc, char ** argv) {
    // Configuration of client and server addresses
    // Binding socket to client address
    // Sending join message to server
}
```

- **Key Steps**: Set the IP address and port, create and bind the socket, then send a "join" message to the server.

### 4. **GUI Thread and Communication Channels**

The client utilizes GUI threads and communication channels for managing user inputs and displaying received messages:

```cpp
auto [gui_thread, gui_tx, gui_rx] = chat::make_gui();
auto [rec_thread, rec_rx] = make_receiver(&sock);
```

- **Interactivity**: This structure allows the client to maintain a responsive UI while handling network communication in parallel.

### 5. **Processing User Commands and Server Responses**

In the main loop, the client responds to user inputs and server messages, translating them into appropriate actions and display updates:

```cpp
for(;!exit_loop;) {
    // Handling commands from GUI
    // Dispatching direct messages or broadcast messages to the server
    // Processing incoming server messages for GUI display
}
```

- **Dynamics**: Whether it's sending messages based on user commands or updating the chat interface with new messages, the client keeps the user experience smooth and engaging.

### Conclusion

The client's implementation showcases an intricate use of threads, network programming, and real-time user interaction. By employing atomic variables, threading, and socket communication, the client can efficiently parse and execute commands, maintain a live chat session, and gracefully handle server responses. This architecture not only meets the requirements for a functional chat application but also lays the groundwork for further enhancements, such as group chats or file sharing.

- **Processing Incoming UI Messages**:
    Implement logic within the main thread to interpret user commands and text inputs, transforming them into appropriate network messages for the server.

- **Handling Server Messages**:
    Within the receiver thread function, continuously listen for messages from the server and use the channel to relay these messages back to the main thread for UI updates.


By accomplishing Task 2, the chat client gains a robust architecture capable of handling interactive user sessions and dynamic message exchanges with the server. This task underscores the importance of concurrency in networked applications and the effective use of threads and channels to maintain smooth communication flows within the chat application.

## Testing the program

The provided chat application, comprised of a server and client, functions as an interactive communication system. It demonstrates robust user interaction, management, and message broadcasting capabilities.

1. **User Initialization:**
   - A client with the username "bob" successfully initiates a session within the chat application. 
   
   - ![testing image](./worksheet2_part2_images/1.png)

2. **Message Broadcasting:**
   - "bob" broadcasts messages to the chat, and the server logs confirm the reception and distribution of these messages to all users. 
   ![testing image](./worksheet2_part2_images/2.png)

3. **Multiple User Handling:**
   - A second client, "seif," joins the chat, illustrating the server's capability to handle multiple users simultaneously.
   - ![testing image](./worksheet2_part2_images/3.png)

4. **Direct Messaging - Bob to Seif:**
   - A direct message is sent from "bob" to "seif," showcasing the private messaging feature of the chat application.
   - ![testing image](./worksheet2_part2_images/4.png)

5. **Direct Messaging - Seif to Bob:**
   - "seif" responds with a direct message back to "bob," validating the two-way communication flow.
   - ![testing image](./worksheet2_part2_images/5.png)

6. **User Leave Notification:**
   - "seif" decides to leave the chat, and the server updates all clients about the change in user status.
   - ![testing image](./worksheet2_part2_images/6.png)

7. **User Re-entry:**
   - "seif" rejoins the chat, testing the system's ability to manage user disconnections and reconnections effectively.
   - ![testing image](./worksheet2_part2_images/7.png)

8. **Initiating Server Shutdown:**
   - "seif" sends a command to terminate the chat session, prompting the server to initiate a shutdown sequence.
   - ![testing image](./worksheet2_part2_images/8.png)

9. **Server and Client Closure:**
   - The server successfully closes, terminating all active sessions and gracefully exiting without issues for all users.
   - ![testing image](./worksheet2_part2_images/9.png)

Each step is designed to validate the essential functionalities of the chat application, ensuring a seamless and robust user experience.

**Server Messages:**
- Server logs succinctly track user actions, from joining to exiting, including direct messages and broadcast notices, displaying efficient process management.

**Client GUI Messages:**
- The client interface updates user lists in real-time, confirms message delivery, and promptly notifies users of others joining or leaving the chat.

In conclusion, the application exhibits reliable communication mechanisms, effective user interaction management, and graceful handling of dynamic chat activities.


## Debug command 
The `DEBUG` macro is utilized within the chat application for outputting debug information, which aids developers in monitoring the internal processes and flow of the application. To prevent these debug messages from cluttering the user interface, the debug output is redirected to a file named `debug.log`.
![testing image](./worksheet2_part2_images/10.png)
![testing image](./worksheet2_part2_images/11.png)
For instance, in the provided screenshots, we can observe this in action. In one of the terminals, the chat server's debug output shows that it is processing various events, such as user joins and list requests, indicating that users are actively interacting with the server. Concurrently, the chat client's UI displays a list of online users, confirming that the client-side is properly rendering the information sent from the server.


Another terminal is used to follow the `debug.log` file in real-time with the command `tail -f debug.log`. This command allows us to see live updates of the client's activities without interrupting the user experience. For example, in the screenshots, you can see the client logging a join message followed by the receipt of an acknowledgment (`JACK`), and later a leave acknowledgment (`LACK`), confirming the client's ability to communicate effectively with the server.

This separation of debug information from user-facing elements exemplifies good development practices, ensuring that users have a clean interface while developers have access to detailed logs for diagnostics and debugging.
