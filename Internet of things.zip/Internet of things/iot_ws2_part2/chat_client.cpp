#include <arpa/inet.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <cstdlib>

#include <atomic>
#include <iostream>

// IOT socket api
#include <iot/socket.hpp>

#include <chat.hpp>
#include <gui.hpp>
#include <colors.hpp>
#include <util.hpp>

namespace {
std::atomic<bool> sent_leave{false};
};

//---------------------------------------------------------------------------------------

/**
 * @brief Convert a string command from the UI into a chat command.
 *  NOTE: It is only a subset of all command types.
 *
 * @param cmd command to convert
 * @return command type ID representing the passed in command
*/
chat::chat_type to_type(std::string cmd) {
    switch(string_to_int(cmd.c_str())) {
    // case string_to_int("join"): return chat::JOIN;
    // case string_to_int("bc"): return chat::BROADCAST;
    case string_to_int("dm"): return chat::DIRECTMESSAGE;
    case string_to_int("list"): return chat::LIST;
    case string_to_int("leave"): return chat::LEAVE;
    case string_to_int("exit"): return chat::EXIT;
    default:
        return chat::UNKNOWN;
    }

  return chat::UNKNOWN; // unknowntype
}

//----------------------------------------------------------------------------------------

std::pair<std::thread, Channel<chat::chat_message>> make_receiver(uwe::socket* sock) {
    // Create a communication channel for sending received chat messages from the receiver thread to the main application
    auto [tx, rx] = make_channel<chat::chat_message>();
 
    // Launch a new thread dedicated to receiving messages from a given socket
    std::thread receiver_thread([tx = std::move(tx), sock]() mutable {
        try {
            // Infinite loop for continuously receiving messages
            for (;;) {
                chat::chat_message msg; // Temporary storage for an incoming message
                sockaddr_in sender_address; // Address structure for storing the sender's address
                size_t sender_address_len = sizeof(sender_address); // Length of the sender's address structure

                // Receive a message from the socket
                int len = sock->recvfrom(&msg, sizeof(msg), 0, (sockaddr*)&sender_address, &sender_address_len);

                // Check if the received message is exactly the size of a chat::chat_message
                if (len == sizeof(chat::chat_message)) {
                    // Send the received message through the channel for processing elsewhere
                    tx.send(msg);

                    // If an EXIT message is received or a LEAVE message after a leave notice has been sent, break the loop
                    if (msg.type_ == chat::EXIT || (msg.type_ == chat::LEAVE && sent_leave.load())) {
                        break;
                    }
                } else {
                    // Log an error if a packet of unexpected size is received
                    DEBUG("Error receiving packet or unexpected packet size\n");
                }
            }
        } catch(...) { // Catch any exceptions that may occur within the receiver thread
            // Log that an exception was caught in the receiver thread
            DEBUG("Caught exception in receiver thread\n");
        }
    });

    // Return the thread and the receiving end of the channel
    return {std::move(receiver_thread), std::move(rx)};
}


int main(int argc, char ** argv) {
    if (argc != 4) {
        printf("USAGE: %s <ipaddress> <port> <username>\n", argv[0]);
        exit(0);
    }

    std::string username{argv[3]};
    // Set client IP address
    uwe::set_ipaddr(argv[1]);

    const char* server_name = "192.168.1.21";

    const int server_port = SERVER_PORT;

    sockaddr_in server_address;
    memset(&server_address, 0, sizeof(server_address));
    server_address.sin_family = AF_INET;

    // creates binary representation of server name and stores it as sin_addr
    inet_pton(AF_INET, server_name, &server_address.sin_addr);

    // htons: port in network order format
    server_address.sin_port = htons(server_port);

    // open socket
    uwe::socket sock{AF_INET, SOCK_DGRAM, 0};

    // port for client
    const int client_port = std::atoi(argv[2]);

    // socket address used for the client
    struct sockaddr_in client_address;
    memset(&client_address, 0, sizeof(client_address));
    client_address.sin_family = AF_INET;
    client_address.sin_port = htons(client_port);
    inet_pton(AF_INET, uwe::get_ipaddr().c_str(), &client_address.sin_addr);

    sock.bind((struct sockaddr *)&client_address, sizeof(client_address));

    chat::chat_message msg = chat::join_msg(username);

    // send data
    int len = sock.sendto(
            reinterpret_cast<const char*>(&msg), sizeof(chat::chat_message), 0,
            (sockaddr*)&server_address, sizeof(server_address));
    DEBUG("Join message (%s) sent, waiting for JACK\n", username.c_str());
    // wait for JACK
    sock.recvfrom(reinterpret_cast<char*>(&msg), sizeof(chat::chat_message), 0, nullptr, nullptr);

    if (msg.type_ == chat::JACK) {
        DEBUG("Received jack\n");

        // create GUI thread and communication channels
        auto [gui_thread, gui_tx, gui_rx] = chat::make_gui();
        auto [rec_thread, rec_rx] = make_receiver(&sock);

        bool exit_loop = false;
        for(;!exit_loop;) {
    // Check if there are any messages from the GUI to handle, and if a leave command hasn't been sent yet
    if (!gui_rx.empty() && !sent_leave) {
        auto result = gui_rx.recv(); // Attempt to receive a message from the GUI
        if (result) { // If a message was received
            auto cmds = split(*result, ':'); // Split the received message into commands based on ':'
            if (cmds.size() > 1) { // Ensure the command has the expected structure
                chat::chat_type type = to_type(cmds[0]); // Convert the first part of the command to a message type
                switch(type) {
                    // Handle EXIT command from GUI
                    case chat::EXIT: {
                        DEBUG("Received Exit command from GUI.");
                        chat::chat_message exit_msg = chat::exit_msg(); // Prepare an exit message
                        // Send the exit message to the server
                        sock.sendto(reinterpret_cast<const char*>(&exit_msg), sizeof(chat::chat_message), 0,
                                    (sockaddr*)&server_address, sizeof(server_address));
                        exit_loop = true;  // Flag to exit the main event loop
                        break;
                    }
                    // Handle LEAVE command from GUI
                    case chat::LEAVE: {
                        DEBUG("Received LEAVE command from GUI.");
                        sent_leave = true; // Mark that a leave command has been issued
                        chat::chat_message leave_msg = chat::leave_msg(); // Prepare a leave message
                        // Send the leave message to the server
                        sock.sendto(reinterpret_cast<const char*>(&leave_msg), sizeof(chat::chat_message), 0, 
                                    (sockaddr*)&server_address, sizeof(server_address));
                        break;
                    }
                    // Placeholder for handling LIST command from GUI
                    case chat::LIST: {
                        DEBUG("Received LIST command from GUI.");
                        // Implementation for handling LIST command should be added here
                        break;
                    }
                    // Handle DIRECTMESSAGE command from GUI
                    case chat::DIRECTMESSAGE: {
                        if (cmds.size() >= 3) { // Ensure the command structure includes recipient and message
                            // Extract the recipient username and the actual message content
                            std::string recipient_username = cmds[1];
                            std::string actual_message = cmds[2];
                            // Concatenate the rest of the message if it was split
                            for (size_t i = 3; i < cmds.size(); ++i) {
                                actual_message += ":" + cmds[i];
                            }
                            // Prepare and send the direct message to the server
                            chat::chat_message dm_msg = chat::dm_msg(username, recipient_username + ":" + actual_message);
                            sock.sendto(reinterpret_cast<const char*>(&dm_msg), sizeof(dm_msg), 0, 
                                        (sockaddr*)&server_address, sizeof(server_address));
                        }
                        break;
                    }
                    // Fallback for other message types or malformed commands
                    default: {
                        DEBUG("Received an unhandled or malformed command from GUI.");
                        break;
                    }
                }
            } else { // If the received command doesn't split into multiple parts, treat it as a broadcast message
                chat::chat_message msg = chat::broadcast_msg(username, *result);
                sock.sendto(reinterpret_cast<const char*>(&msg), sizeof(chat::chat_message), 0,
                            (sockaddr*)&server_address, sizeof(server_address));
            }
        }
    }

    // Check for any received network messages to handle
                        if (!rec_rx.empty() && !exit_loop) {
                // Attempt to receive a message from the receiving channel
                auto result = rec_rx.recv();
                if (result) { // If a message is successfully received
                    // Handle the received message based on its type
                    switch ((*result).type_) {
                        case chat::LEAVE: {
                            // Construct a message indicating a user has left the chat
                            std::string left_username(reinterpret_cast<char*>((*result).username_));
                            std::string leave_message = left_username + " has left the chat.";
                            // Display the leave message in the GUI console
                            chat::display_command leave_cmd{chat::GUI_CONSOLE, leave_message};
                            gui_tx.send(leave_cmd);
                            break;
                        }
                        case chat::EXIT: {
                            // Log receipt of an EXIT command and signal to exit the main loop
                            DEBUG("EXIT command received.");
                            exit_loop = true;
                            break;
                        }
                        case chat::LACK: {
                            // Log receipt of a LACK command, indicating leave acknowledgment
                            DEBUG("LACK (Leave Acknowledgment) received.");
                            if (sent_leave) {
                                // If a leave command was previously sent, exit the main loop
                                exit_loop = true;
                            }
                            break;
                        }
                        case chat::BROADCAST: {
                            // Construct and display a broadcast message in the GUI console
                            std::string sender(reinterpret_cast<char*>((*result).username_));
                            std::string content = std::string(reinterpret_cast<char*>((*result).message_));
                            std::string display_message = sender + ": " + content;
                            chat::display_command cmd{chat::GUI_CONSOLE, display_message};
                            gui_tx.send(cmd);
                            break;
                        }
                        case chat::DIRECTMESSAGE: {
                            // Construct and display a direct message in the GUI console
                            std::string sender(reinterpret_cast<char*>((*result).username_));
                            std::string content = std::string(reinterpret_cast<char*>((*result).message_));
                            std::string dm_display_message = "Direct Message from " + sender + ": " + content;
                            chat::display_command dm_cmd{chat::GUI_CONSOLE, dm_display_message};
                            gui_tx.send(dm_cmd);
                            break;
                        }
                        case chat::LIST: {
                            // Process a list of users, handling both usernames and potential 'END' signal
                            bool end = false; // Flag to detect 'END' signal in the list
                            // Parse usernames from the first part of the message
                            auto users = split(std::string{(char*)(*result).username_}, ':');
                            for (const auto& u: users) {
                                if (u == "END") {  
                                    end = true; // 'END' signal found, stop processing further
                                    break;
                                }
                                // Display each username in the GUI user list
                                chat::display_command cmd{chat::GUI_USER_ADD, u};
                                gui_tx.send(cmd);
                            }

                            // If 'END' signal was not in the first part, check the second part of the message
                            if (!end) {
                                auto users = split(std::string{(char*)(*result).message_}, ':');
                                for (const auto& u: users) {
                                    if (u == "END") {
                                        break; // Stop processing if 'END' signal is found
                                    }
                                    // Potential implementation for additional user list handling
                                }
                            }

                            break;
                        }
                        case chat::ERROR: {
                            // Handle ERROR messages (implementation depends on application requirements)
                            break;
                        }
                        default: {
                            // Handle any other message types not explicitly mentioned
                        }
                    }
                }
            }

        }

        DEBUG("Exited loop\n");
        // send message to GUI to exit
        chat::display_command cmd{chat::GUI_EXIT};
        gui_tx.send(cmd);
        gui_thread.join();
        rec_thread.join();

        // so done...
        DEBUG("Time to rest\n");
    }
    else {
        DEBUG("Received invalid jack\n");
    }

    return 0;
}
